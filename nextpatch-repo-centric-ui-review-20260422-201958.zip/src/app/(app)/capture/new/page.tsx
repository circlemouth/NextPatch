import { redirect } from "next/navigation";

export default function CapturePage() {
  redirect("/repositories");
}
